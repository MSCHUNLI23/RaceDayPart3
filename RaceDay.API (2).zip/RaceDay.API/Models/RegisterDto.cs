﻿namespace RaceDay.API.Models
{
    public class RegisterDto
    {
        public string Name { get; set; }
        public string Surname { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string Role { get; set; } // Organiser or Participant
    }
}
